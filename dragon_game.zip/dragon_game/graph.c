#include"graph.h"
#include <stdlib.h>


void arxikkopoihsh(graph_t **grafos){
     (*grafos)->vertices = NULL;
     (*grafos)->num_vertices = 0;
     (*grafos)->max_id = 0;
}

void prosthiki_komvou(graph_t **grafos, vertex_t *komvos){
    int palio_megethos = (*grafos)->num_vertices;
    komvos = (vertex_t* )malloc(sizeof(vertex_t));
    if (komvos == NULL){
         exit(1);
    }else{
         (*grafos)->num_vertices++;
        (*grafos)->vertices = realloc((*grafos)->vertices, ((*grafos)->num_vertices) * sizeof(vertex_t*));
          if ((*grafos)->vertices == NULL){
              exit(1);
        }else{
            komvos->edges = NULL;
             if (palio_megethos == 0){
                 (*grafos)->max_id = 1;
             }else{
                 (*grafos)->max_id += 1;
             }
             komvos->id = (*grafos)->max_id;
             (*grafos)->vertices[(*grafos)->num_vertices - 1] = komvos;
          }
     }
}

void sundesh_duo_komvwn(vertex_t *komvos1, vertex_t *komvos2){
    edge_t *curr1 = (edge_t* )malloc(sizeof(edge_t));
    curr1->to = komvos2;
    edge_t *curr2 = (edge_t* )malloc(sizeof(edge_t));
    curr2->to = komvos1;
    if (curr1 != NULL && curr2 != NULL){
        curr1->next = komvos1->edges;
        komvos1->edges = curr1;

        curr2->next = komvos2->edges;
        komvos2->edges = curr2;
    }else{
        exit(1);
    }
}

edge_t *anazhthsh_akmhs(vertex_t *komvos, vertex_t *komvos_point){
    edge_t *curr = NULL;
    for (curr = komvos->edges; curr != NULL; curr = curr->next){
        if (curr->to == komvos_point){
            return curr;
        }
    }

    return NULL;
}

void diagrafh_akmhs(vertex_t *komvos, vertex_t *komvos_point){
     edge_t *curr = komvos->edges;
     edge_t *prev = NULL;
     while (curr != NULL){
         if (curr->to == komvos_point){
             if (curr == komvos->edges){
                 komvos->edges = curr->next;
                 free(curr);
                 break;
             }else{
                 prev->next = curr->next;
                 free(curr);
                 break;
             }
         }
         prev = curr;
         curr = curr->next;
    }
}

void afairesh_akmwn(vertex_t *komvos1, vertex_t *komvos2){
     diagrafh_akmhs(komvos1, komvos2);
     diagrafh_akmhs(komvos2, komvos1);
}

void katastrofh_listas_akmwn(vertex_t *komvos){
     edge_t *curr = komvos->edges;
     edge_t *prev = NULL;
     while (curr != NULL){
            prev = curr;
            curr = curr->next;
            free(prev);
     }

     komvos->edges = NULL;
}

void afairesh_komvou(vertex_t *af_komvos, graph_t **grafos){
     int thesi;
     for (int i = 0; i < (*grafos)->num_vertices; i++){
         if (anazhthsh_akmhs((*grafos)->vertices[i], af_komvos) != NULL){
             diagrafh_akmhs((*grafos)->vertices[i], af_komvos);
         }
     }
     katastrofh_listas_akmwn(af_komvos);
     for (int j = 0; j < (*grafos)->num_vertices; j++){
         if ((*grafos)->vertices[j] == af_komvos){
             thesi = j;
         }
     }
      free(af_komvos);
     (*grafos)->vertices[thesi] = (*grafos)->vertices[(*grafos)->num_vertices - 1];
     (*grafos)->num_vertices--;
     (*grafos)->vertices = realloc((*grafos)->vertices, (*grafos)->num_vertices * sizeof(vertex_t*));
}

void apodesmeush_grafou(graph_t **grafos){
    for (int i = 0; i < (*grafos)->num_vertices; i++){
        katastrofh_listas_akmwn((*grafos)->vertices[i]);
        free((*grafos)->vertices[i]);
    }
    (*grafos)->num_vertices = 0;
    (*grafos)->max_id = 0;
    free((*grafos)->vertices);

}

int anazhthsh_komvou(vertex_t *komvos, graph_t **grafos){
    for (int i = 0; i < (*grafos)->num_vertices; i++){
        if ((*grafos)->vertices[i] == komvos){
            return i;
        }
    }


    return -1;
}

int plithos_akmwn_sugk(vertex_t *komvos, graph_t **grafos){
    int plithos = 0;
    for (int i = 0; i < (*grafos)->num_vertices; i++){
        if (anazhthsh_akmhs((*grafos)->vertices[i], komvos) != NULL){
            plithos++;
        }
    }

    return (plithos);
}

unsigned int  mhkos_listas(vertex_t *komvos){
    int plithos = 0;
    edge_t *curr = komvos->edges;
    while(curr != NULL){
          plithos++;
          curr = curr->next;
    }

    return(plithos);
}

unsigned int *taj_anag(vertex_t *komvos){
         int mhkos = mhkos_listas(komvos);
         int i = 0;
         unsigned int *pinakas = (unsigned int* )malloc(mhkos * sizeof(unsigned int));
         if (pinakas == NULL){
             exit(1);
         }
         edge_t *curr = komvos->edges;
         while(curr != NULL){
             pinakas[i] = curr->to->id;
             i++;
             curr = curr->next;
         }
         for (int i = 0; i < mhkos - 1; i++){
             for (int j = 0; j < mhkos - 1; j++){
                  if (pinakas[j] > pinakas[j + 1]){
                      unsigned int temp = pinakas[j];
                      pinakas[j] = pinakas[j + 1];
                      pinakas[j + 1] = temp;
                  }
             }
         }

         return(pinakas);
}
