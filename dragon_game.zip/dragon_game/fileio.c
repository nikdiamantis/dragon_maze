#include"fileio.h"
#include <fcntl.h>
#include <unistd.h>
#include "game.h"
#include "graph.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>


int apothikeush(graph_t *grafos, player_t *paikths){
     char neo_onoma[NAME_SIZE + 5];
     snprintf((neo_onoma), sizeof(neo_onoma), "%s.sav", paikths->name);

    int ep = open(neo_onoma, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (ep == -1){return -1;}

    if (write(ep, MAGIC_NUMBER, strlen(MAGIC_NUMBER)) == -1){ close(ep); return -2;}
    if (write(ep, &paikths->arrows, sizeof(unsigned int)) == -1){ close(ep); return -2;}
    if (write(ep, &paikths->room->id, sizeof(unsigned int)) == -1){ close(ep); return -2;}
    if (write(ep, &grafos->max_id, sizeof(unsigned int)) == -1){ close(ep); return -2;}
    if (write(ep, &grafos->num_vertices, sizeof(unsigned int)) == -1){ close(ep); return -2;}
    if (write(ep, MAGIC_NUMBER, strlen(MAGIC_NUMBER)) == -1){ close(ep); return -2;}
    for (int i = 0; i < grafos->num_vertices; i++){
        if (write(ep, &grafos->vertices[i]->id, sizeof(unsigned int)) == -1){ close(ep); return -2;}
        if (write(ep, &grafos->vertices[i]->contents, sizeof(contents_t)) == -1){ close(ep); return -2;}
    }


    for (int p = 0; p < grafos->num_vertices; p++){
        unsigned int plithos = mhkos_listas(grafos->vertices[p]);
        if (write(ep, &plithos, sizeof(unsigned int)) == -1){close(ep); return -2;}
        unsigned int *pinakas = taj_anag(grafos->vertices[p]);
        for (int j = 0; j < plithos; j++){
            if (write(ep, &pinakas[j], sizeof(unsigned int)) == -1){close(ep); return -2;}
        }

        free(pinakas);
    }

    if (write(ep, MAGIC_NUMBER, strlen(MAGIC_NUMBER)) == -1){close(ep); return -2;}

    return 1;
}

int anagnwsh(graph_t *grafos, player_t *paikths){
    unsigned int megethos;
    unsigned int thalamos;
    unsigned int max_id;
    char onoma[NAME_SIZE + 5];
    unsigned int veloi;
    snprintf(onoma, sizeof(onoma), "%s.sav", paikths->name);
    int fd = open(onoma, O_RDONLY);
    if (fd == -1){ return -2;}

    char buffer[32];
    if (read(fd, buffer, strlen(MAGIC_NUMBER)) == -1){close(fd); return -1;}
    if (strncmp(buffer, MAGIC_NUMBER, strlen(MAGIC_NUMBER)) != 0){close(fd); return -1;}


    if (read(fd, &veloi, sizeof(unsigned int)) == -1){close(fd); return -1;}
    if (read(fd, &thalamos, sizeof(unsigned int)) == -1){close(fd); return -1 ;}
    if (read(fd, &max_id, sizeof(unsigned int)) == -1){close(fd); return -1;}
    if (read(fd, &megethos, sizeof(unsigned int)) == -1){close(fd); return -1;}

    char buffer2[32];
    if (read(fd, buffer2, strlen(MAGIC_NUMBER)) == -1){close(fd); return -3;}
    if (strncmp(buffer2, MAGIC_NUMBER, strlen(MAGIC_NUMBER)) != 0){close(fd); return -3;}

    for (int i = 0; i < megethos; i++){
        vertex_t *komvos = NULL;
        prosthiki_komvou(&grafos, komvos);
        if (read(fd, &grafos->vertices[i]->id, sizeof(unsigned int)) == -1){close(fd); return -1;}
        if (read(fd, &grafos->vertices[i]->contents, sizeof(contents_t)) == -1){close(fd); return -1;}
    }
    grafos->max_id = max_id;
    for (int p = 0; p < grafos->num_vertices; p++){
        unsigned int plithos;
        if (read(fd, &plithos, sizeof(unsigned int)) == -1){close(fd); return -1;}
        for (int k = 0; k < plithos; k++){
            unsigned int geit_id;
                if (read(fd, &geit_id, sizeof(unsigned int)) == -1){close(fd); return -1;}
                for (int m = 0; m < grafos->num_vertices; m++){
                    if (grafos->vertices[m]->id == geit_id){
                        if (anazhthsh_akmhs(grafos->vertices[p], grafos->vertices[m]) == NULL){
                            sundesh_duo_komvwn(grafos->vertices[p], grafos->vertices[m]);
                            break;
                        }
                    }
                }
        }
    }

    char buffer3[32];
    if (read(fd, buffer3, strlen(MAGIC_NUMBER)) == -1){close(fd); return -1;}
    if (strncmp(buffer3, MAGIC_NUMBER, strlen(MAGIC_NUMBER)) != 0){close(fd); return -1;}
    int flag = 0;
    for (int g = 0; g < grafos->num_vertices; g++){
        if (grafos->vertices[g]->id == thalamos){
            paikths->room = grafos->vertices[g];
            flag = 1;
            break;
        }
    }
    if (!flag){
        return -3;
    }

    close(fd);

    return 1;
}

int elegxos_domhs(player_t *paikths){
    char onoma[NAME_SIZE + 5];
    snprintf(onoma, sizeof(onoma), "%s.sav", paikths->name);
    int fd = open(onoma, O_RDONLY);
    if (fd == -2){return 0;}

    char buffer[32];
    if (read(fd, buffer, strlen(MAGIC_NUMBER)) == -1){close(fd); return 0;}
    if (strncmp(buffer, MAGIC_NUMBER, strlen(MAGIC_NUMBER)) != 0){close(fd); return 0;}

    if (lseek(fd, 4 * sizeof(unsigned int), SEEK_CUR) == -1){close(fd); return -1;}

    char buffer2[32];
    if (read(fd, buffer2, strlen(MAGIC_NUMBER)) == -1){close(fd); return 0;}
    if (strncmp(buffer2, MAGIC_NUMBER, strlen(MAGIC_NUMBER)) != 0){close(fd); return 0;}

    if (lseek(fd, -strlen(MAGIC_NUMBER), SEEK_END) == -1){close(fd); return -1;}

    char buffer3[32];
    if (read(fd, buffer3, strlen(MAGIC_NUMBER)) == -1){close(fd); return 0;}
    if (strncmp(buffer3, MAGIC_NUMBER, strlen(MAGIC_NUMBER)) != 0){close(fd); return 0;}

    close(fd);

    return 1;
}

int elegxos_onom(player_t *paikths){
    char onoma[NAME_SIZE + 5];
    snprintf(onoma, sizeof(onoma), "%s.sav", paikths->name);
    int flag = open(onoma, O_WRONLY | O_CREAT | O_EXCL, 0644);
    if (flag == -1){return 0;}

    close(flag);

    return 1;
}
