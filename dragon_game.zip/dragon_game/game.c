#include"game.h"
#include "graph.h"
#include"msg.h"
#include<stdio.h>
#include<ctype.h>
#include "libhw3.h"
#include "random.h"
/*
 * main_menu
 *
 * Prints the main game menu, reads and returns the user's requested action.
 */
menu_action_t main_menu()
{
	char action;
	while (1) {
		printf(MAIN_MENU_MSG);
		scanf(" %c", &action);
		switch (toupper(action)) {
			case 'N':
				return NEW;
			case 'L':
				return LOAD;
			case 'S':
				return SAVE;
			case 'C':
				return CONTINUE;
			case 'Q':
				return QUIT;
			case 'H':
				return HELP;
			default:
				while (getchar() != '\n');
				printf(WRONG_SELECTION_MSG);
		}
	}
	return QUIT; // unreachable
}

/*
 * in_game_menu
 *
 * Prints the menu of options available while a game is in progress,
 * reads and returns the user's requested action.
 */
game_action_t in_game_menu()
{
	char action;
	while(1) {
		printf(GAME_MENU_MSG);
		scanf(" %c", &action);
		switch (toupper(action)) {
			case 'M':
				return MOVE;
			case 'S':
				return SHOOT;
			case 'E':
				return EXIT;
			default:
				while (getchar() != '\n');
				printf(WRONG_SELECTION_MSG);
		}
	}
}

void arxikopoihsh_paikth(player_t *paikths){
    printf(NAME_REQUEST_MSG);
    scanf("%s", paikths->name);
    printf(GREETING_MSG, paikths->name);
    paikths->arrows = INIT_ARROWS;
}

graph_t* dhmiourgia_paixnidiou(int vathmos_duskolias, player_t *paikths){
    graph_t *grafos = create_game_graph(vathmos_duskolias);
    paikths->room = grafos->vertices[0];

    return (grafos);
}

game_status_t diadikasia_paixn(graph_t *grafos, player_t *paikths){
    while(1){
        int flag = 0;
         #ifdef DEBUG
                print_graph(grafos);
         #endif

         printf(ENTER_ROOM_MSG);
         if (paikths->room->contents == MINE){

             printf(TRIGGERED_MINE_MSG);
             afairesh_komvou(paikths->room, &grafos);
             unsigned int nea_thesi = get_rand_range(0, grafos->num_vertices);
             paikths->room = grafos->vertices[nea_thesi];
             flag = 1;
             continue;

         }else if (paikths->room->contents == PORTAL){

             printf(TRIGGERED_PORTAL_MSG);
             vertex_t *neos_komv = NULL;
             unsigned int thesi1, thesi2;
             prosthiki_komvou(&grafos, neos_komv);
             grafos->vertices[grafos->num_vertices - 1]->contents = EMPTY;
             while(1){
                thesi1 = get_rand_range(0, grafos->num_vertices);
                if (thesi1 != grafos->num_vertices - 1)
                    break;
             }
            while(1){
                thesi2 = get_rand_range(0, grafos->num_vertices);
                if (thesi2 != thesi1 && thesi2 != grafos->num_vertices - 1)
                    break;
            }
            sundesh_duo_komvwn(grafos->vertices[grafos->num_vertices - 1], grafos->vertices[thesi1]);
            sundesh_duo_komvwn(grafos->vertices[grafos->num_vertices - 1], grafos->vertices[thesi2]);
            paikths->room = grafos->vertices[grafos->num_vertices - 1];
             flag = 1;
             continue;

         }else if (paikths->room->contents == DRAGON){

             printf(ENCOUNTERED_DRAGON_MSG);

             return (GAME_OVER);

         }else if (paikths->room->contents == ARROW){

             paikths->arrows++;
             printf(FOUND_ARROW_MSG, paikths->arrows);
             paikths->room->contents = EMPTY;
        }

        if (flag == 0){
            int plithos = plithos_akmwn_sugk(paikths->room, &grafos);
            unsigned int  pinakas[plithos];
            int metrhths = 0;
            printf(PASSAGE_INFO_MSG, plithos);
            for (int i = 0; i < grafos->num_vertices; i++){
                if (anazhthsh_akmhs(grafos->vertices[i], paikths->room) != NULL){
                    pinakas[metrhths] = grafos->vertices[i]->id;
                    metrhths++;
                }
            }
            for (int p = 0; p < plithos - 1; p++){
                for (int k = 0; k < plithos - 1; k++){
                    if (pinakas[k] > pinakas[k + 1]){
                        unsigned int temp = pinakas[k];
                        pinakas[k] = pinakas[k + 1];
                        pinakas[k + 1] = temp;
                    }
                }
            }

            for (int j = 0; j < plithos; j++){
                printf(" %d", pinakas[j]);
            }
            printf("\n");
        }

        for (int p = 0; p < grafos->num_vertices; p++){
            if (anazhthsh_akmhs(grafos->vertices[p], paikths->room) != NULL){
                if (grafos->vertices[p]->contents == DRAGON){
                    printf(DETECTED_DRAGON_MSG);
                    break;
                }
            }
        }

        for (int g = 0; g < grafos->num_vertices; g++){
            if (anazhthsh_akmhs(grafos->vertices[g], paikths->room) != NULL){
                if (grafos->vertices[g]->contents == PORTAL){
                    printf(DETECTED_PORTAL_MSG);
                    break;
                }
            }
        }
        int moved = 0;
        while(1){
        game_action_t drast = in_game_menu();
        switch (drast){
            case EXIT:{
                 return (IN_PROGRESS);
                 break;
            }

            case MOVE:{
                int id;
                int flag2 = 0;
                int thesi;
                    scanf("%d", &id);
                    for (int d = 0; d < grafos->num_vertices; d++){
                        if (anazhthsh_akmhs(grafos->vertices[d], paikths->room) != NULL){
                            if (grafos->vertices[d]->id == id){
                                flag2 = 1;
                                thesi = d;
                                break;
                            }
                        }
                    }

                    if (!flag2){
                        printf(NO_PASSAGE_MSG);
                        continue;
                    }else{
                        paikths->room = grafos->vertices[thesi];
                        moved = 1;
                        break;
                    }

                break;
            }

            case SHOOT:{
                int id;
                int flag3 = 0;
                int thesi;
                scanf("%d", &id);
                for (int o = 0; o < grafos->num_vertices; o++){
                    if (anazhthsh_akmhs(grafos->vertices[o], paikths->room) != NULL){
                        if (grafos->vertices[o]->id == id){
                            flag3 = 1;
                            thesi = o;
                            break;
                        }
                    }
                }
                if (!flag3){
                    printf(NO_PASSAGE_MSG);
                    continue;
                }else if (paikths->arrows == 0){
                    printf(NO_ARROWS_MSG);
                    continue;
                }

                if (flag3 == 1 && grafos->vertices[thesi]->contents == DRAGON){
                    printf(SHOT_DRAGON_MSG);
                    return (GAME_OVER);
                }else if (flag3 == 1 && grafos->vertices[thesi]->contents != DRAGON){
                    paikths->arrows--;
                    printf(ARROW_MISSED_MSG, paikths->arrows);
                    moved = 1;
                }

                break;
            }

            default:{
                break;
            }
        }
        if (moved){
            break;
        }

     }
  }
}
