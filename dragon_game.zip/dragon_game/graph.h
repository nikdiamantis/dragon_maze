#ifndef _HW3_GRAPH
#define _HW3_GRAPH

typedef enum {
	EMPTY, PORTAL, MINE, ARROW, DRAGON
} contents_t;//periexomeno thalamou.

struct _edge;

typedef struct  _vertex {//(komvos)
	unsigned int id; // unique id
	contents_t contents;
	struct _edge *edges; // a vertex connects to a list of edges
} vertex_t;//monadiko id , periexomeno, lista apo akmes pou odhgoun se allous thalamous giaa kathe thalamo.

typedef struct _edge {//(akmh)
	vertex_t *to;  // the other adjacent vertex
	struct _edge *next;
} edge_t; //apla diasundedemenh lista apo surrages.

typedef struct {//(grafos)
	unsigned int max_id; // maximum vertex id given at any time
	unsigned int num_vertices;
	vertex_t **vertices;  // the graph is a dynamic array of pointers to vertices
} graph_t;//megisto id , arithmos komvwn, dunamikos pinakas apo komvous.

void arxikkopoihsh(graph_t **grafos);
void prosthiki_komvou(graph_t **grafos, vertex_t *komvos);
void sundesh_duo_komvwn(vertex_t *komnvos1, vertex_t *komnvos2);
int anazhthsh_komvou(vertex_t *komvos, graph_t **grafos);
int plithos_akmwn_sugk(vertex_t *komvos, graph_t **grafos);
edge_t *anazhthsh_akmhs(vertex_t *komvos, vertex_t *komvos_point);
void diagrafh_akmhs(vertex_t *komvos, vertex_t *komvos_point);
void afairesh_akmwn(vertex_t *komvos1, vertex_t *komvos2);
void katastrofh_listas_akmwn(vertex_t *komvos);
void afairesh_komvou(vertex_t *af_komvos, graph_t **grafos);
void apodesmeush_grafou(graph_t **grafos);
unsigned int mhkos_listas(vertex_t *komvos);
unsigned int *taj_anag(vertex_t *komvos);
#endif
