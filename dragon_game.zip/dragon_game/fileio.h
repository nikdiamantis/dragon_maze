#include "game.h"
/*
 * Operations relating to loading and saving game files.
 */
#ifndef _HW3_FILEIO
#define _HW3_FILEIO
#define MAGIC_NUMBER "Dr460N5D3N"
int apothikeush(graph_t *grafos, player_t *paikths);
int anagnwsh(graph_t *grafos, player_t *paikths);
int elegxos_domhs(player_t *paikths);
int elegxos_onom(player_t *paikths);

#endif
