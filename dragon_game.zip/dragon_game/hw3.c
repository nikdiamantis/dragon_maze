#include"graph.h"
#include"game.h"
#include"random.h"
#include"hw3.h"
#include"msg.h"
#include<stdio.h>
#include<stdlib.h>
#include "fileio.h"

int main (int argc, char *argv[]){
	unsigned int level_factor;
	menu_action_t action;
	player_t paikths;
	graph_t *grafos;

 	if (argc > 2) {
		fprintf(stderr, "Additional arguments ignored.\n");
	}
	// Get level factor (default 0) and use it to initialize the RNG
	level_factor = 0;
	if (argc == 2) {
		level_factor = atoi(argv[1]);
	}
	set_seed(level_factor);

	printf(WELCOME_MSG);

	// there's no active game initially
	game_status_t status = GAME_OVER;

	arxikopoihsh_paikth(&paikths);
	do {
		action = main_menu();
		switch (action) {
			case NEW:{
				 if (status == IN_PROGRESS){
					 char epilogh;
  					 printf(CONFIRM_NEW_GAME_MSG);
  					 scanf(" %c", &epilogh);
                     if (epilogh == 'y'){
                         apodesmeush_grafou(&grafos);
                         status = GAME_OVER;
                     }else if (epilogh == 'n'){
						 break;
					  }
					}
				   grafos = dhmiourgia_paixnidiou(level_factor, &paikths);
                    status = diadikasia_paixn(grafos, &paikths);
			    break;
			}
			case LOAD:{
			   char epilogh;
				    if (status == IN_PROGRESS){
    					printf(CONFIRM_NEW_GAME_MSG);
    					scanf(" %c", &epilogh);
    					if (epilogh == 'y'){
                        int domh = elegxos_domhs(&paikths);
    					   if (domh == -2){
    						  printf(OPEN_ERROR_MSG);
    						  break;
    						}else if (domh == -1){
    						  printf(READ_ERROR_MSG);
    						  break;
    						}else if (domh == 0){
    						   printf(CORRUPTED_ERROR_MSG);
    						   break;
    						}else{
								vertex_t *dwmatio = paikths.room;
								game_status_t katastash = status;
								graph_t *gra = grafos;

								int fortwsh = anagnwsh(grafos, &paikths);
    							if (fortwsh == -2){
    							   printf(OPEN_ERROR_MSG);
								   apodesmeush_grafou(&grafos);
								   grafos = gra;
								   paikths.room = dwmatio;
								   status = katastash;
								   break;
    							}else if (fortwsh == -1){
    							   printf(READ_ERROR_MSG);
								   apodesmeush_grafou(&grafos);
								   grafos = gra;
								   paikths.room = dwmatio;
								   status = katastash;
								   break;
    							}else if (fortwsh == -3){
    							   printf(CORRUPTED_ERROR_MSG);
								   apodesmeush_grafou(&grafos);
								   grafos = gra;
								   paikths.room = dwmatio;
								   status = katastash;
								   break;
    							}else if (fortwsh == 1){
                                    status = diadikasia_paixn(grafos, &paikths);
                                }
    						}
    					}
				    }else{
						 int domh = elegxos_domhs(&paikths);
					   if (domh == -2){
						  printf(OPEN_ERROR_MSG);
						  break;
  						}else if (domh == -1){
						  printf(READ_ERROR_MSG);
						  break;
  						}else if (domh == 0){
   						   printf(CORRUPTED_ERROR_MSG);
   						   break;
  						}else{
                            vertex_t *dwmatio = paikths.room;
                            game_status_t katastash = status;
                            graph_t *gra = grafos;
                            int fortwsh = anagnwsh(grafos, &paikths);
 							if (fortwsh == -2){
  							   printf(OPEN_ERROR_MSG);
                               apodesmeush_grafou(&grafos);
                               grafos = gra;
                               paikths.room = dwmatio;
                               status = katastash;
                               break;
 							}else if (fortwsh == -1){
  							   printf(READ_ERROR_MSG);
  							    apodesmeush_grafou(&grafos);
                                grafos = gra;
                                paikths.room = dwmatio;
                                status = katastash;
                               break;
 							}else if (fortwsh == -3){
  							   printf(CORRUPTED_ERROR_MSG);
                                apodesmeush_grafou(&grafos);
                                grafos = gra;
                                paikths.room = dwmatio;
                                status = katastash;
                               break;
 							}else if (fortwsh == 1){
                               status = diadikasia_paixn(grafos, &paikths);
                            }
  						}
					}
			   break;
			}
			case SAVE:{
				char epilogh;
				 if (status != IN_PROGRESS){
					 printf(NO_GAME_IN_PROGRESS_MSG);
					 break;
				 }else{
					 int uparjh = elegxos_onom(&paikths);
                     if (uparjh == 0){
						printf(FILE_EXISTS_MSG);
						scanf(" %c", &epilogh);
						if (epilogh == 'y'){
							int sfalma = apothikeush(grafos, &paikths);
							if (sfalma == -1){
								printf(OPEN_ERROR_MSG);
								break;
							}else if (sfalma == -2){
								printf(WRITE_ERROR_MSG);
								break;
							}else if (sfalma == 1){
								printf(SAVE_OK_MSG);
							}
						}
				     }else{
						 int sfalma = apothikeush(grafos, &paikths);
						 if (sfalma == -1){
							 printf(OPEN_ERROR_MSG);
							 break;
						 }else if (sfalma == -2){
							 printf(WRITE_ERROR_MSG);
							 break;
						 }else if (sfalma == 1){
							 printf(SAVE_OK_MSG);
						 }
					}
				}
				break;
			}

			case CONTINUE:{
                if (status != IN_PROGRESS){
					printf(NO_GAME_IN_PROGRESS_MSG);
				}else{
					status = diadikasia_paixn(grafos, &paikths);
				}
				break;
			}

			case HELP:
				printf(INSTRUCTIONS_MSG);
				break;

			case QUIT:{
				char epilogh;
                if (status == IN_PROGRESS){
					printf(CONFIRM_QUIT_MSG);
					scanf(" %c", &epilogh);
					if (epilogh == 'y'){
						apodesmeush_grafou(&grafos);
						return 0;
					}else if (epilogh == 'n'){
						break;
					}
				}else{
					return 0;
				}
				break;
			}
		}

	} while (action != QUIT);







	return 0;
}
