#ifndef _HW3_GAME
#define _HW3_GAME

#include"graph.h"

#ifndef INIT_ARROWS
#define INIT_ARROWS 2//arxiko plithos velwn
#endif

#define NAME_SIZE 32 /* player name size */

typedef enum {
	GAME_OVER,  /* the dragon has been shot or the player has been eaten*/
	IN_PROGRESS /* the game is still ongoing */
} game_status_t;

typedef enum {
    QUIT, NEW, LOAD, SAVE, CONTINUE, HELP
} menu_action_t;

typedef enum {
    EXIT, /* stop/interrupt the current game */
	MOVE, /* move to a neighboring room */
	SHOOT /* shoot an arrow towards a neighboring room */
} game_action_t;//drasthriothta sto paixnidi

typedef struct {
    char name[NAME_SIZE];//onoma paikth
	unsigned int arrows;//plithos velwn(apothema)
	vertex_t *room;  /* player's location *///thalamos pou vrisketai o paikths
} player_t;//paikths


/*
 * main_menu
 *
 * Prints the main game menu and returns the user's requested action.
 */
menu_action_t main_menu();//ektupwsh menu

/*
 * in_game_menu
 *
 * Prints the menu of options available while a game is in progress
 * and returns the user's requested action.
 */
game_action_t in_game_menu();//ektupwsh menu

void arxikopoihsh_paikth(player_t *paikths);
graph_t* dhmiourgia_paixnidiou(int vathmos_duskolias, player_t *paikths);
game_status_t diadikasia_paixn(graph_t *grafos, player_t *paikths);
#endif
